##Part 01

setwd("C:\\Users\\it24102949\\Desktop\\IT24102949")
data<- read.table("Exercise - Lab 05.txt",header = TRUE,sep = ",")
fix(data)

names(data)<-c("Time")
attach(data)


##Part 02

hist(Time,main = "Delivery_Time_minutes")
histogram<-hist(Time,main = "Delivery_Time_minutes",breaks =  seq(20, 70, length = 9), right =  TRUE)
histogram<-hist(Time,main = "Delivery_Time_minutes",breaks =  seq(20, 70, length = 9), right =  FALSE)

##Part 03 
##If the bars are tall in the middle and taper on both sides → symmetric (bell-shaped).
##If the bars are higher on the left, tail to the right → positively skewed.
##If the bars are higher on the right, tail to the left → negatively skewed.

##Part 04
freq <- hist(Time, main = "Delivery_Time_minutes", breaks = seq(20, 70, length = 9), right = TRUE)
cumfreq <- cumsum(freq$counts)
class_boundaries <- freq$breaks[-1]

plot(class_boundaries, cumfreq,
     type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Time",
     ylab = "Frequency",
     ylim = c(0, max(cumfreq)))  # Use ylim, not ylin

