setwd("E:\\IT24102949")
getwd()

data<-read.csv("Exercise.csv",header=TRUE)

student_data<-read.csv("Exercise.csv")

View(student_data)

summary(student_data$X1)

par(mar = c(4,4,2,1))
hist(student_data$X1,
     main = "Histrogram of Age",
     xlab = "Age",
)

table(student_data$X2)

barplot(student_data$X2,main = "Gender",
        xlab = "Gender",
        ylab = "Frequency",
)

boxplot(X1 ~ X3,data = student_data,
        main = "Age according to accommodation",
        xlab = "Accommodation Type",
        ylab = "Age")

